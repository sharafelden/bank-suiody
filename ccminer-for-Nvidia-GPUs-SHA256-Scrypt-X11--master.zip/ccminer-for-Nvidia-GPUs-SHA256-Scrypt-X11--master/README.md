ccminer
=======

Christian Buchner's &amp; Christian H.'s CUDA miner project
